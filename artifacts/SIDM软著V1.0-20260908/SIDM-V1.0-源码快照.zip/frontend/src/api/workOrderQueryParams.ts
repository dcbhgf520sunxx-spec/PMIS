export type WorkOrderListParams = {
  problemDesc?: string;
  productId?: string;
  problemType?: string | string[];
  urgency?: number;
  status?: number;
  isOverdue?: boolean;
  filterFollowerId?: string;
  viewKey?: 'all' | 'mine';
  currentUserId?: string;
  submitterName?: string;
  submitTimeFrom?: string;
  submitTimeTo?: string;
  expectedResolveDateFrom?: string;
  expectedResolveDateTo?: string;
  creatorId?: string;
  createdAtFrom?: string;
  createdAtTo?: string;
  current?: number;
  pageSize?: number;
  sortField?: string;
  sortOrder?: 'ascend' | 'descend';
};

export function toWorkOrderSortField(field?: string) {
  const sortMap: Record<string, string> = {
    problemDesc: 'problem_desc',
    productName: 'product_id',
    problemType: 'problem_type',
    followerId: 'follower_id',
    urgency: 'urgency',
    status: 'status',
    isOverdue: 'is_overdue',
    submitterName: 'submitter_name',
    submitterDept: 'submitter_dept',
    submitTime: 'submit_time',
    expectedResolveDate: 'expected_resolve_date',
    creatorName: 'creator_name',
    createdAt: 'created_at'
  };
  return field ? sortMap[field] || field : undefined;
}

export function buildWorkOrderQueryParams(params: WorkOrderListParams = {}) {
  return {
    problem_desc: params.problemDesc,
    product_id: params.productId,
    problem_type: Array.isArray(params.problemType) ? params.problemType.join(',') : params.problemType,
    urgency: params.urgency,
    status: params.status,
    is_overdue: params.isOverdue === undefined ? undefined : Number(params.isOverdue),
    filter_follower_id: params.filterFollowerId,
    view_key: params.viewKey,
    current_user_id: params.currentUserId,
    submitter_name: params.submitterName,
    submit_time_from: params.submitTimeFrom,
    submit_time_to: params.submitTimeTo,
    expected_resolve_date_from: params.expectedResolveDateFrom,
    expected_resolve_date_to: params.expectedResolveDateTo,
    creator_id: params.creatorId,
    created_at_from: params.createdAtFrom,
    created_at_to: params.createdAtTo,
    page: params.current,
    pageSize: params.pageSize,
    sort_field: toWorkOrderSortField(params.sortField),
    sort_order: params.sortOrder
  };
}
