import { useEffect, useState } from 'react';
import type { ProColumns } from '@ant-design/pro-components';
import {
  ActionBar, AdminInput, AdminRangePicker, AdminSelect, AdminTextAction, CompactFilterBar,
  DeleteConfirmAction, DetailLinkCell, OperationColumnActions, PermissionButton,
  StatusConfirmAction, StatusTag, TemplateListPage, listRouteCodecs, useCommittedFilters,
  usePageReturnNavigation, useTemplateServerListData
} from '../../../components/admin';
import { deleteProduct, getProductList, updateProductStatus } from '../../../api/productApi';
import { getUserOptions } from '../../../api/userApi';
import type { ProductRecord } from '../types';

const defaults = { name: '', ownerIds: [] as string[], status: undefined as number | undefined, creatorId: undefined as string | undefined, createdAtRange: [] as unknown[] };
const date = (value: any) => value?.format?.('YYYY-MM-DD');

export function ProductListPage() {
  const { navigateWithReturn: navigate } = usePageReturnNavigation('/products');
  const [users, setUsers] = useState<Array<{ label: string; value: string }>>([]);
  const filters = useCommittedFilters(defaults, { urlSync: true, codecs: { name: listRouteCodecs.string, ownerIds: listRouteCodecs.stringArray, status: listRouteCodecs.number, creatorId: listRouteCodecs.string, createdAtRange: listRouteCodecs.dateArray } });
  const list = useTemplateServerListData<ProductRecord>({
    queryKey: ['products', filters.appliedFilters, filters.revision],
    request: async ({ current, pageSize, sortField, sortOrder }) => {
      const createdAtRange = filters.appliedFilters.createdAtRange || [];
      return getProductList({
        name: filters.appliedFilters.name || undefined,
        owner_ids: filters.appliedFilters.ownerIds.join(',') || undefined,
        status: filters.appliedFilters.status,
        creator_id: filters.appliedFilters.creatorId,
        created_at_from: date(createdAtRange[0]),
        created_at_to: date(createdAtRange[1]),
        page: current,
        pageSize,
        sort_field: sortField,
        sort_order: sortOrder
      });
    },
    urlSync: true
  });
  const load = list.reload;

  useEffect(() => { getUserOptions().then(setUsers); }, []);

  const columns: ProColumns<ProductRecord>[] = [
    { title: '序号', width: 60, fixed: 'left', render: (_, __, index) => list.renderIndex(index) },
    { title: '产品名称', dataIndex: 'name', width: 220, fixed: 'left', sorter: true, sortOrder: list.sortState.field === 'name' ? list.sortState.order : null, render: (_, row) => <DetailLinkCell onClick={() => navigate(`/products/${row.id}`)}>{row.name}</DetailLinkCell> },
    { title: '负责人', dataIndex: 'ownerName', width: 130, sorter: true, sortOrder: list.sortState.field === 'ownerName' ? list.sortState.order : null },
    { title: '产品描述', dataIndex: 'description', width: 260, ellipsis: true, sorter: true, sortOrder: list.sortState.field === 'description' ? list.sortState.order : null, render: (_, row) => row.description || '-' },
    { title: '状态', dataIndex: 'status', width: 100, sorter: true, sortOrder: list.sortState.field === 'status' ? list.sortState.order : null, render: (_, row) => <StatusTag status={row.status === 1 ? 'enabled' : 'disabled'} /> },
    { title: '创建人', dataIndex: 'creatorName', width: 120, sorter: true, sortOrder: list.sortState.field === 'creatorName' ? list.sortState.order : null },
    { title: '创建时间', dataIndex: 'createdAt', width: 170, sorter: true, sortOrder: list.sortState.field === 'createdAt' ? list.sortState.order : null },
    {
      title: '操作', valueType: 'option', width: 170, fixed: 'right',
      render: (_, row) => (
        <OperationColumnActions>
          <AdminTextAction onClick={() => navigate(`/products/${row.id}/edit`)}>编辑</AdminTextAction>
          <StatusConfirmAction variant="text" action={row.status === 1 ? 'disable' : 'enable'} entityName="产品" targetName={row.name} onConfirm={async () => { await updateProductStatus(row.id, row.status === 1 ? 0 : 1); await load(); }}>{row.status === 1 ? '停用' : '启用'}</StatusConfirmAction>
          <DeleteConfirmAction variant="text" entityName="产品" targetName={row.name} successMessage="删除成功" onConfirm={async () => { await deleteProduct(row.id); await load(); }}>删除</DeleteConfirmAction>
        </OperationColumnActions>
      )
    }
  ];

  return (
    <TemplateListPage<ProductRecord>
      title="产品管理"
      error={list.error}
      onRetry={load}
      actions={<ActionBar><PermissionButton permission="product" type="primary" onClick={() => navigate('/products/new')}>新增产品</PermissionButton></ActionBar>}
      filter={<CompactFilterBar items={[
        { key: 'name', label: '产品名称', node: <AdminInput size="small" value={filters.draftFilters.name} onChange={(event) => filters.setDraftFilters((prev) => ({ ...prev, name: event.target.value }))} onPressEnter={filters.commitFilters} /> },
        { key: 'owner', label: '负责人', node: <AdminSelect size="small" mode="multiple" value={filters.draftFilters.ownerIds} options={users} onChange={(value) => filters.setDraftFilters((prev) => ({ ...prev, ownerIds: value }))} /> },
        { key: 'status', label: '状态', node: <AdminSelect size="small" value={filters.draftFilters.status} options={[{ label: '启用', value: 1 }, { label: '停用', value: 0 }]} onChange={(value) => filters.setDraftFilters((prev) => ({ ...prev, status: value }))} /> },
        { key: 'creatorId', label: '创建人', node: <AdminSelect size="small" value={filters.draftFilters.creatorId} options={users} onChange={(value) => filters.setDraftFilters((prev) => ({ ...prev, creatorId: value }))} /> },
        { key: 'createdAtRange', label: '创建时间', wide: true, node: <AdminRangePicker size="small" value={filters.draftFilters.createdAtRange as never} onChange={(value) => filters.setDraftFilters((prev) => ({ ...prev, createdAtRange: value || [] }))} /> }
      ]} onSearch={filters.commitFilters} onReset={filters.resetFilters} />}
      table={{ columns, dataSource: list.pagedRows, loading: list.loading, pagination: false, search: false, onChange: list.handleTableChange, tableAlertRender: false, scroll: { x: 1240 } }}
      pagination={list.pagination}
    />
  );
}
