import { type FormEvent, type MouseEvent, useCallback, useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { App, Button, Card, Input, Typography } from 'antd';
import {
  ApartmentOutlined,
  FieldTimeOutlined,
  InteractionOutlined,
  LockOutlined,
  NodeIndexOutlined,
  SafetyCertificateOutlined,
  ThunderboltOutlined,
  UserOutlined
} from '@ant-design/icons';
import { logoutAccessSession } from '../../../api/accessLogApi';
import { derivePermissions, exchangeWecomTicket, getUserPreference, login } from '../../../api/authApi';
import { PasswordChangeModal } from '../../account/components/PasswordChangeModal';
import { useAuthStore } from '../../../stores/authStore';
import robotMini from '../../../assets/login/robot-mini.png';
import { parseWecomLoginSearch } from '../wecomLogin';
import './LoginPage.css';

type FocusedField = 'account' | 'password' | null;

type Ripple = {
  id: number;
  x: number;
  y: number;
  size: number;
};

export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { message } = App.useApp();
  const setAuth = useAuthStore((state) => state.setAuth);
  const setPreference = useAuthStore((state) => state.setPreference);
  const mustChangePassword = useAuthStore((state) => state.mustChangePassword);
  const setMustChangePassword = useAuthStore((state) => state.setMustChangePassword);
  const accessSessionId = useAuthStore((state) => state.accessSessionId);
  const clearAuth = useAuthStore((state) => state.clearAuth);
  const [account, setAccount] = useState('');
  const [password, setPassword] = useState('');
  const [focusedField, setFocusedField] = useState<FocusedField>(null);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [buttonPressed, setButtonPressed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const handledWecomQuery = useRef('');

  const enterPreferredPage = useCallback(async () => {
    const preference = await getUserPreference();
    setPreference(preference);
    message.success('登录成功');
    navigate(preference.default_route || '/home', { replace: true });
  }, [message, navigate, setPreference]);

  useEffect(() => {
    const query = parseWecomLoginSearch(location.search);
    const queryKey = query.ticket ? `ticket:${query.ticket}` : query.errorMessage ? `error:${location.search}` : '';
    if (!queryKey || handledWecomQuery.current === queryKey) return;
    handledWecomQuery.current = queryKey;

    if (query.errorMessage) {
      message.error(query.errorMessage);
      navigate('/login', { replace: true });
      return;
    }

    setSubmitting(true);
    exchangeWecomTicket(query.ticket as string)
      .then(async (result) => {
        setAuth({
          token: result.token,
          user: result.user,
          menus: result.menus,
          permissions: derivePermissions(result.menus),
          accessSessionId: result.access_session_id,
          mustChangePassword: false
        });
        await enterPreferredPage();
      })
      .catch((error) => {
        message.error(error instanceof Error ? error.message : '企微登录失败');
        navigate('/login', { replace: true });
      })
      .finally(() => setSubmitting(false));
  }, [enterPreferredPage, location.search, message, navigate, setAuth]);

  const handleForcedPasswordExit = async () => {
    await logoutAccessSession(accessSessionId).catch(() => undefined);
    clearAuth();
    setAccount('');
    setPassword('');
  };

  const createRipple = (event: MouseEvent<HTMLElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 1.7;
    const id = Date.now();
    setRipples((items) => [
      ...items,
      {
        id,
        x: event.clientX - rect.left - size / 2,
        y: event.clientY - rect.top - size / 2,
        size
      }
    ]);
    window.setTimeout(() => {
      setRipples((items) => items.filter((item) => item.id !== id));
    }, 760);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setButtonPressed(true);
    window.setTimeout(() => setButtonPressed(false), 180);

    if (!account.trim()) {
      message.error('工号或手机号不能为空');
      return;
    }
    if (!password) {
      message.error('密码不能为空');
      return;
    }

    setSubmitting(true);
    try {
      const result = await login({
        account: account.trim(),
        password
      });
      const firstLogin = result.first_login === 1;
      setAuth({
        token: result.token,
        user: result.user,
        menus: result.menus,
        permissions: derivePermissions(result.menus),
        accessSessionId: result.access_session_id,
        mustChangePassword: firstLogin
      });
      if (firstLogin) {
        message.warning('首次登录，请先修改密码');
        return;
      }
      await enterPreferredPage();
    } catch (error) {
      message.error(error instanceof Error ? error.message : '登录失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <section className="login-page">
      <div className="login-intro" aria-hidden="true">
        <div className="login-hero-headline">
          <div className="login-hero-robot">
            <img src={robotMini} alt="" />
          </div>
          <Typography.Title className="login-hero-title" level={1}>
            不怕事情多，就怕没着落
          </Typography.Title>
        </div>
        <p className="login-hero-copy">
          该排的安排，该推进的推进，该解决的别躲着。项目自然越走越顺。
        </p>
        <div className="login-signal-grid">
          <span>
            <InteractionOutlined />
            产品规划
          </span>
          <span>
            <NodeIndexOutlined />
            项目推进
          </span>
          <span>
            <ApartmentOutlined />
            交付闭环
          </span>
        </div>
      </div>
      <Card className="login-card" onMouseDown={createRipple}>
        <div className="login-ripple-layer" aria-hidden="true">
          {ripples.map((ripple) => (
            <span
              className="login-ripple"
              key={ripple.id}
              style={{
                height: ripple.size,
                left: ripple.x,
                top: ripple.y,
                width: ripple.size
              }}
            />
          ))}
        </div>
        <div className="login-card-header">
          <span className="login-card-badge">
            <SafetyCertificateOutlined />
            安全登录
          </span>
        </div>
        <Typography.Title className="login-title" level={3}>
          <span className="login-title-text">智能数管</span>
          <span className="login-title-code">SIDM</span>
        </Typography.Title>
        <form autoComplete="on" className="login-form" onSubmit={handleSubmit}>
          <label
            className={`login-field ${focusedField === 'account' ? 'is-focused' : ''}`}
            htmlFor="login-username"
          >
            <Input
              autoComplete="username"
              id="login-username"
              name="username"
              onBlur={() => setFocusedField(null)}
              onChange={(event) => setAccount(event.target.value)}
              onFocus={() => setFocusedField('account')}
              placeholder="请输入账号或手机号"
              prefix={<UserOutlined />}
              value={account}
            />
          </label>
          <label
            className={`login-field ${focusedField === 'password' ? 'is-focused' : ''}`}
            htmlFor="login-password"
          >
            <Input.Password
              autoComplete="current-password"
              id="login-password"
              name="password"
              onBlur={() => setFocusedField(null)}
              onChange={(event) => setPassword(event.target.value)}
              onFocus={() => setFocusedField('password')}
              placeholder="请输入密码"
              prefix={<LockOutlined />}
              value={password}
            />
          </label>
          <Button
            className={`login-submit ${buttonPressed ? 'is-pressed' : ''}`}
            htmlType="submit"
            loading={submitting}
            type="primary"
          >
            登录系统
          </Button>
        </form>
        <div className="login-trust-row" aria-hidden="true">
          <span>
            <ThunderboltOutlined />
            协同推进
          </span>
          <span>
            <FieldTimeOutlined />
            全程留痕
          </span>
        </div>
      </Card>
      </section>
      <PasswordChangeModal
        open={mustChangePassword}
        forced
        onForcedExit={handleForcedPasswordExit}
        onSuccess={() => {
          setMustChangePassword(false);
          void enterPreferredPage();
        }}
      />
    </>
  );
}
